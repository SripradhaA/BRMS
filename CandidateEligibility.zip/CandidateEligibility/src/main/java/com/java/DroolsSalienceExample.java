package com.java;

//import java.util.List;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import tm.order.OrderData;

//import com.redhat.sampledrools.Candidate;



/**
 * This is a sample class to launch a rule.
 */
public class DroolsSalienceExample {
    private String topic;
    
    public DroolsSalienceExample(String topic) {
        this.topic = topic;
    }

    public static final void main(String[] args) {
        try {
            // load up the knowledge base
            KieServices ks = KieServices.Factory.get();
            KieContainer kContainer = ks.getKieClasspathContainer();
            KieSession kSession = kContainer.newKieSession("defaultKieSession");
            System.out.println("test");
            /*Candidate c = new Candidate();    		
    		c.setName("priya");
    		c.setAge(21);
    		c.setEligibility(false);*/
           
            OrderData c=new OrderData();
            c.setAmount(501);
          
    		
    			System.out.println("test1");
    			kSession.insert(c);
    		
    		System.out.println("************* Fire Rules **************");

            kSession.fireAllRules(); 
            System.out.println("************************************");
           //System.out.println("Candidate details\n" + c.getDiscount()+"\n" + c.getAge() +"\n"+ c.getEligibility());
            System.out.println("Amount: "+c.getDiscount());
            
            
                        
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public String getTopic() {
        return topic;
    }
        
    public String introduceYourself() {
        return "Drools 6.2.0.Final";
    }
}