/**
 * 
 */
$("#create-comparebutton").button().click(function() {
		window.location.href = "manageVSLP.html";
	});


$("#comparebutton").button().click(function() {
	window.location.href = "compareVSLP.html";
});