// Tabs 
$(function() { $( "#tabs" ).tabs();  });  