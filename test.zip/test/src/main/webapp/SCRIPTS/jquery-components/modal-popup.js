// Dialog Modal 

$(function() {
	$("#dialog-modal-name-here").dialog({
		autoOpen : false,
		resizable : false,
		height : 530, //Height Modifiable
		width : 690, //Width Modifiable 
		modal : true,
	});
});
