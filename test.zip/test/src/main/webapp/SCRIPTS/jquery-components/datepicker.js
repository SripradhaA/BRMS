$(function() {
        //Date Picker
            $("#datepicker").datepicker({
            dateFormat: 'dd/mm/yy',
            showOn: "both",
            showOtherMonths: true,
            selectOtherMonths: true,
            buttonImage: "IMAGES/calandar.png",
            buttonImageOnly: true,
            buttonText: "Select Date from Calandar",
            constrainInput: false
                });
            
            
            
            
            $("#datepicker2").datepicker({
                dateFormat: 'dd/mm/yy',
                showOn: "both",
                showOtherMonths: true,
                selectOtherMonths: true,
                buttonImage: "IMAGES/calandar.png",
                buttonImageOnly: true,
                buttonText: "Select Date from Calandar",
                constrainInput: false,
                    });
            
            $("#datepicker3").datepicker({
                dateFormat: 'dd/mm/yy',
                showOn: "both",
                showOtherMonths: true,
                selectOtherMonths: true,
                buttonImage: "IMAGES/calandar.png",
                buttonImageOnly: true,
                buttonText: "Select Date from Calandar",
                constrainInput: false,
                    });
            
            $("#datepicker4").datepicker({
                dateFormat: 'dd/mm/yy',
                showOn: "both",
                showOtherMonths: true,
                selectOtherMonths: true,
                buttonImage: "IMAGES/calandar.png",
                buttonImageOnly: true,
                buttonText: "Select Date from Calandar",
                constrainInput: false,
                    });
            
           });
