//Tooltips 
$(function() { $( document ).tooltip({ track: true });  });  