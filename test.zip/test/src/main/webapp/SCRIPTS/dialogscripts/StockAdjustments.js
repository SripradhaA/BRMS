/**
 * 
 */

$(document).ready(function() {
	$('#adjustmentTable').dataTable({"bFilter": false,"bInfo": false,"bPaginate": false,});

});


