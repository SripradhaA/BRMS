/**
 *
 */

$(document).ready(function() {
	
	$(document.getElementById('Submit')).on('click', function(event) {
		
		alert('Adjustment Request Submitted');
		window.location.replace("./StockAdjustments.html");


	});
	

});
